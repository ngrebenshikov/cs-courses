import java.util.Scanner;

public class solver {
	public class Q1 {}
	public static void main(String[] args) {
		solver s = new solver();
		s.run();
	}
	
	public void run() {
		Q1 q1 = new Q1();
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        System.out.print(a+b);
	}
}
