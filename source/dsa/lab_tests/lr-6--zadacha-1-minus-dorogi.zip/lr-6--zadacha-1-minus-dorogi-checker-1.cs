﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace sa_lab6_1_chk {
    public class checker {
	    interface Action<T> {
		    void doAction(T o);
	    }

	    class Graph {
		    public class NodeInfo {
			    public const int Cleared = 0;
			    public const int Checked = 1;
			    public int data;
			    public int @checked;
			    public int group = 0;
    			
			    public NodeInfo(int data) {
				    this.data = data;
				    @checked = Cleared;
			    }
		    }
    		
		    private NodeInfo[] nodes;
		    private int[,] arcs;
		    private int[,] pathes;
		    private int count;
		    private int maxNodesCount;

		    public Graph(int maxNodesCount) {
			    this.maxNodesCount = maxNodesCount;
			    nodes = new NodeInfo[maxNodesCount];
			    arcs =  new int[maxNodesCount,maxNodesCount];
			    for (int i=0; i<maxNodesCount; i++)
				    for (int j=0; j<maxNodesCount; j++) {
					    arcs[i,j] = int.MaxValue / 2;
				    }
			    pathes = null;
		    }

		    public void addArc(int from, int to, int data) {
			    arcs[from,to] = data;
			    addSingleNode(from);
			    addSingleNode(to);
		    }
		    public void addSingleNode(int node) {
			    if (nodes[node] == null) {
				    nodes[node] = new NodeInfo(node);
				    count++;
			    }
		    }
    		
		    public int getNodesCount() { return count; }
		    public int getMaxNodesCount() { return maxNodesCount; }

		    /**
		     * 
		     * @param action
		     * @return number of groups
		     */
		    public int dfs(Action<int> action) {
			    int group = 0;
			    for(int i = 0; i < maxNodesCount; i++) {
				    if (null != nodes[i]) {
					    if (nodes[i].@checked != NodeInfo.Checked) {
						    dfs(i, action, group);
						    group++;
					    }
				    }
			    }
			    return group;
		    }
    		
		    private void dfs(int node, Action<int> action, int group) {
			    if (nodes[node].@checked == NodeInfo.Checked) {
				    return;
			    }
			    if (null != action) {
				    action.doAction(node);
			    }
			    nodes[node].@checked = NodeInfo.Checked;
			    nodes[node].group = group;
			    for(int i = 0; i < maxNodesCount; i++) {
				    if (arcs[node,i] < int.MaxValue / 2) {
					    dfs(i, action, group);
				    }
			    }
		    }
    		
		    public void floyd() {
			    pathes = new int[count+1,count+1];
			    for (int i=1; i<=count; i++)
				    for (int j=0; j<=count; j++)
					    pathes[i,j] = arcs[i,j];
			    for (int j=1; j<=count; j++)
				    pathes[j,j] = 0;
			    for (int k=1; k<=count; k++)
				    for (int i=1; i<=count; i++)
					    for (int j=1; j<=count; j++)
						    if (pathes[i,k] + pathes[k,j] < pathes[i,j]) {
							    pathes[i,j] = pathes[i,k] + pathes[k,j]; 
						    }
		    }
    		
		    public int getMinimalPath(int from, int to) {
			    return pathes[from,to];
		    }
    		
		    public NodeInfo getNodeInfo(int node) {
			    return nodes[node];
		    }
	    }

	    class solver {
		    public Graph graph;
		    public int groupsNumber;
    		
		    public void solve(StreamReader sc) {
                string[] line = sc.ReadLine().Split(' ');
                int N = Convert.ToInt32(line[0]);
                int M = Convert.ToInt32(line[1]);
    			
			    graph = new Graph(N+1);
    			
			    for (int i=0; i < M; i++) {
                    string[] ints = sc.ReadLine().Split(' ');
                    int p = Convert.ToInt32(ints[0]);
                    int q = Convert.ToInt32(ints[1]);
                    int r = Convert.ToInt32(ints[2]);
                    graph.addArc(p, q, r);
				    graph.addArc(q, p, r);
			    }
			    for (int i=1; i <= N; i++) {
				    graph.addSingleNode(i);
			    }
    			
	            groupsNumber = graph.dfs(null);
	            graph.floyd();
		    }
    		
		    public int getMaxLength(int group) {
	            int from = 1;
	            int to = 1;
	            int length = -1;
			    for (int i=1; i<=graph.getMaxNodesCount()-1; i++) {
				    Graph.NodeInfo fromNode = graph.getNodeInfo(i);
				    if (null == fromNode || fromNode.group != group) continue;
				    for (int j=1; j<=graph.getMaxNodesCount()-1; j++) {
					    Graph.NodeInfo toNode = graph.getNodeInfo(j);
					    if (null == toNode || toNode.group != group) continue;
					    if (length < graph.getMinimalPath(i, j)) {
						    from = i;
						    to = j;
						    length = graph.getMinimalPath(i, j);
					    }
				    }
			    }
			    return length;
		    }
    		
		    public bool isInOneGroup(int from, int to) {
			    Graph.NodeInfo fromNode = graph.getNodeInfo(from);
			    Graph.NodeInfo toNode = graph.getNodeInfo(to);
			    if (null != fromNode && null != toNode && fromNode.group == toNode.group) {
				    return true;
			    } else {
				    return false;
			    }
		    }
    		
	    }

	    const int WrongAnswer = 0xAB; 
	    const int Accepted = 0xAC; 
	    const int PresentationError = 0xAA; 
	    const int BadCheckerOrInput = 0xA3; 

	    public static void Main(String[] args) {
		    checker c = new checker();
		    try {
			    if (!c.check(
					    new StreamReader("input.txt"),
					    new StreamReader("pattern.txt"),
					    new StreamReader("output.txt")
					    )) {
				    Environment.Exit(WrongAnswer);
			    } else {
                    Environment.Exit(Accepted);
			    }
		    } catch(Exception e) {
                Environment.Exit(WrongAnswer);
		    }
	    }

        public bool check(StreamReader input, StreamReader ans, StreamReader res) {
		    solver s = new solver();
		    s.solve(input);

		    int groupsCount = Convert.ToInt32(res.ReadLine());
    		
		    if (groupsCount != s.groupsNumber) return false;

		    int[] groups = new int[groupsCount];
		    for (int i=0; i < groupsCount; i++) groups[i]=0;
    		
		    for (int i=0; i < groupsCount; i++) {
                string[] ints = res.ReadLine().Split(' ');
			    int from = Convert.ToInt32(ints[0]);
                int to = Convert.ToInt32(ints[1]);
                int length = Convert.ToInt32(ints[2]);
    			
			    if (!s.isInOneGroup(from, to)) return false;
			    int group = s.graph.getNodeInfo(from).group;
    			
			    if (groups[group] > 0) return false; //this group has been processed

			    if (length != s.graph.getMinimalPath(from, to) || 
					    length != s.getMaxLength(group)) return false;
    			
			    groups[group] = 1;
    			
		    }
    		
		    return true;
	    }
    }
}